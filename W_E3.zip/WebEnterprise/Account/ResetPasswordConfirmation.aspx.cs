﻿using System.Web.UI;

namespace WebEnterprise.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}